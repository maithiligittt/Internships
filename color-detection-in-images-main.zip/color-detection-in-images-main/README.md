Color-Identification-in-Images
AUTHOR - DEVELOPED BY: PAGARE MAITHILI Implement an image color detector which identifies all the colors in an image or video. ● Below resources are just for references you can use any library/approach to achieve the goal. ● Resources: link1 ● Task submission:

Host the code on GitHub Repository (public).
Record the code and output in a video.
Share links of code (GitHub) as a post on YOUR LinkedIn profile.
Submit the LinkedIn link in Task Submission Form when shared with you.
Please read FAQs on how to submit the tasks.
