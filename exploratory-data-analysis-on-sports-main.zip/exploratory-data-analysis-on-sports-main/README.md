Author - Pagare Maithili

The Sparks Foundation - Data Science and Business Analysis
Task 5 - Exploratory Data Analysis - Sports

Problems
    1.As a sports analysts, find out the most successful teams, players and factors contributing win or loss of a team.
    2.Suggest teams or players a company should endorse for its products.

Data Insights
    1.2011, 2012, and 2013 has highest number of matches
    2.Mumbai Indians is the top IPL team and Chennai Superkings second.
    3.Bowl First team have more chance of winning.
    4.Winning toss team choose to feild first.
    5.In finals Field first have more chance of winning
    6.In finals toss winning choose field first.
    7.CH gayle and AB de villers are the top IPL players
    8.Shikar Dhawan hit most Four in IPL
    9.CH gayle hit most Six in IPL
    10.Virat Kholi hit maximum runs in IPL
    11.Sk Raina played maximum matchs
    12.Caught Out is most common type of out in IPL
    13.SL Malinga take maximum wickets
    
Dataset: https://bit.ly/34SRn3b
    

