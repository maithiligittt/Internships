Author: Pagare Maithili

The Sparks Foundation - Data Science and Business Analytics

Task 3: Exploratory Data Analysis - Retail
Problem Statement: Perform ‘Exploratory Data Analysis’ on dataset ‘SampleSuperstore’ This task is about Exploratory Data Analysis - Retail where the task focuses on a business manager who will try to find out weak areas where he can work to make more profit.

Dataset: https://bit.ly/3i4rbWl
